﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sif.Framework.Utils
{
    public class Extensions
    {
        public static string  createdBy = "SIFAdmin";
        public  static int statusId = 1;
    }
}
