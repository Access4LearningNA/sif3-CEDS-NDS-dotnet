﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Xml.Linq;
using Sif.NdsProvider.Model;

using Sif.NdsProvider.Services;
using Sif.Framework.Providers;
using System.IO;
using System.Xml.Serialization;

namespace Sif.NdsProvider.Controllers
{
    [Route("api/[controller]")]
    public class TestController : BasicProvider<School>//Controller
    {
        #region Constructor
        public TestController()
                    : base(new SchoolService())
        {
        }
        #endregion
        [HttpPost]
        public string Post([FromBody]School value)
        {
            //string data = Request.Content.ReadAsStringAsync();
          //var obj=  new XmlSerializer(typeof(School)).Deserialize(new StringReader(value.ToString()));
            return value.ToString();
        }
    }
}