﻿using AutoMapper;
using Sif.NdsProvider.Model;
using SIF.NDSDataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Sif.NdsProvider.Services.Commons;

namespace Sif.NdsProvider.Mappers
{
    public class StudentMapper : Profile
    {
        public override string ProfileName
        {
            get { return "StudentMapper"; }
        }
        public StudentMapper()
        {
            Mapper.Initialize(cfg => cfg.CreateMap<Student, PersonDetail>()
            .ForMember(dest => dest.Birthdate, map => map.MapFrom(src => src.demographics.birthDate))
            .ForMember(dest => dest.BirthdateVerification, map => map.MapFrom(src => src.demographics.birthDateVerification))
            );
        }
    }
}
